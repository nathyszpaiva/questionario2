// Função que busca um produto pelo nome em um array de produtos
function encontrarProdutoPorNome(produtos, nomeProduto) {
    // Loop para percorrer todos os produtos
    for (let i = 0; i < produtos.length; i++) {
      // Verifica se o nome do produto atual é igual ao nome buscado
      if (produtos[i].nome === nomeProduto) {
        // Retorna o objeto do produto encontrado
        return produtos[i];
      }
    }
    // Retorna undefined se nenhum produto com o nome for encontrado
    return undefined;
  }
  
  const listaProdutos = [
    { nome: "Caneta", preco: 2.5 },
    { nome: "Caderno", preco: 15.0 }
  ];
  
  // Busca o produto "Caderno" na lista
  const produtoEncontrado = encontrarProdutoPorNome(listaProdutos, "Caderno");
  
  // Exibe o produto encontrado ou undefined
  console.log("Produto encontrado:", produtoEncontrado);
  