
  // Função que verifica se o comprimento do username está entre 3 e 10 caracteres
function usernameValido(username) {
    // Obtém o comprimento da string username
    const comprimento = username.length;
    // Retorna true se o comprimento estiver entre 3 e 10 (inclusive), caso contrário false
    return comprimento >= 3 && comprimento <= 10;
  }
  
  const nomeUsuario1 = "usuario";
  const nomeUsuario2 = "ab";
  
  // Verifica se os nomes de usuário são válidos e exibe
  console.log(`O username "${nomeUsuario1}" é válido? ${usernameValido(nomeUsuario1)}`);
  console.log(`O username "${nomeUsuario2}" é válido? ${usernameValido(nomeUsuario2)}`);
  