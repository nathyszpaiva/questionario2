// Função que junta palavras de um array usando hífens como separador
function juntarComHifens(palavras) {
    // Inicializa uma string vazia para armazenar o resultado
    let resultado = "";
    // Loop para percorrer todas as palavras do array
    for (let i = 0; i < palavras.length; i++) {
      // Adiciona a palavra atual ao resultado
      resultado += palavras[i];
      // Adiciona um hífen se não for a última palavra
      if (i < palavras.length - 1) {
        resultado += "-";
      }
    }
    // Retorna a string resultante com as palavras separadas por hífens
    return resultado;
  }
  
  const palavras = ["um", "dois", "tres"];
  
  // Chama a função para juntar as palavras com hífens
  const stringComHifens = juntarComHifens(palavras);
  
  // Exibe a string resultante
  console.log("String com hífens:", stringComHifens);
  