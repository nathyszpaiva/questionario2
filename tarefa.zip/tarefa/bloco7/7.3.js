// Função que recebe um array de produtos e retorna um array com apenas os nomes
function listarNomesProdutos(produtos) {
    // Inicializa um array vazio para armazenar os nomes
    const nomes = [];
    // Loop para percorrer todos os produtos
    for (let i = 0; i < produtos.length; i++) {
      // Adiciona o nome do produto atual ao array nomes
      nomes.push(produtos[i].nome);
    }
    // Retorna o array com os nomes dos produtos
    return nomes;
  }
  
  const listaProdutos = [
    { nome: "Caneta", preco: 2.5 },
    { nome: "Caderno", preco: 15.0 }
  ];
  
  // Chama a função para obter a lista de nomes
  const nomesProdutos = listarNomesProdutos(listaProdutos);
  
  // Exibe o array com os nomes dos produtos
  console.log("Nomes dos produtos:", nomesProdutos);
  