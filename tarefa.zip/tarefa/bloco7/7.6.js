// Função que conta quantos espaços em branco existem em uma frase
function contarEspacos(frase) {
    // Inicializa o contador de espaços com 0
    let contador = 0;
    // Loop para percorrer cada caractere da frase
    for (let i = 0; i < frase.length; i++) {
      // Verifica se o caractere atual é um espaço em branco
      if (frase[i] === " ") {
        // Incrementa o contador de espaços
        contador++;
      }
    }
    // Retorna o número total de espaços encontrados
    return contador;
  }
  
  const frase = "Contar quantos espaços existem nesta frase";
  
  // Chama a função para contar os espaços e exibe o resultado
  console.log(`Número de espaços na frase: ${contarEspacos(frase)}`);
  