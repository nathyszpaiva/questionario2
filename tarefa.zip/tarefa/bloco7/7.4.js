// Função que recebe um array de produtos e retorna a soma dos preços
function somarPrecosProdutos(produtos) {
    // Inicializa a variável soma com 0
    let soma = 0;
    // Loop para percorrer todos os produtos
    for (let i = 0; i < produtos.length; i++) {
      // Adiciona o preço do produto atual à soma
      soma += produtos[i].preco;
    }
    // Retorna a soma total dos preços
    return soma;
  }
  
  const listaProdutos = [
    { nome: "Caneta", preco: 2.5 },
    { nome: "Caderno", preco: 15.0 }
  ];
  
  // Chama a função para somar os preços dos produtos
  const total = somarPrecosProdutos(listaProdutos);
  
  // Exibe o valor total da soma dos preços
  console.log("Valor total dos produtos:", total);
  