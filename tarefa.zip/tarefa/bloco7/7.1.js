// Função que cria uma lista com dois produtos, cada um com nome e preço
function criarListaProdutos() {
    // Retorna um array com dois objetos produto
    return [
      { nome: "Caneta", preco: 2.5 },
      { nome: "Caderno", preco: 15.0 }
    ];
  }
  
  // Chama a função e armazena o array retornado
  const listaProdutos = criarListaProdutos();
  
  // Exibe a lista de produtos
  console.log("Lista de produtos:", listaProdutos);
  