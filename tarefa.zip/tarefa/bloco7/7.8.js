// Função que recebe uma string e retorna o primeiro caractere
function pegarPrimeiraLetra(texto) {
    // Retorna o caractere na posição 0 da string
    return texto[0];
  }
  
  const nomeCompleto = "João Silva";
  
  // Chama a função para obter a primeira letra do nome completo
  const primeiraLetra = pegarPrimeiraLetra(nomeCompleto);
  
  // Exibe a primeira letra
  console.log("Primeira letra:", primeiraLetra);
  