function despedida(nome) { // Função para criar uma mensagem de despedida com o nome fornecido
    return `Até logo, ${nome}!`; // Retorna a string "Até logo, [nome]!"
  }
  
  const nomeUsuario = "Maria"; // Nome
  
  console.log(despedida(nomeUsuario)); // Exibe a mensagem de despedida personalizada
  