function metade(numero) { // Função para calcular a metade de um número
    return numero / 2; // Retorna o número dividido por 2
  }
  
  const valor = 10; // Valor
  
  console.log(`A metade de ${valor} é ${metade(valor)}.`); // Calcula a metade e exibe
  