function mostrarStatus(status) { // Função para mostrar o status atual de uma operação no console
    console.log(`Status: ${status}`); // Imprime no console a string "Status: " seguida do status recebido
  }
  
  const statusOperacao = "Em andamento"; // Status
  
  mostrarStatus(statusOperacao); // Chama a função para exibir o status no console
  