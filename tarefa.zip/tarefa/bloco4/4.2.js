function perimetroQuadrado(lado) { // Função para calcular o perímetro de um quadrado dado o tamanho do lado
    return 4 * lado; // Retorna o perímetro calculado como 4 vezes o lado
  }
  
  const ladoSala = 5; // Tamanho do lado da sala em metros
  
  console.log(`O perímetro do quadrado é: ${perimetroQuadrado(ladoSala)} metros.`); // Calcula o perímetro e exibe
  