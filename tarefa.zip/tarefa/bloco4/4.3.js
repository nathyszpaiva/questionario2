function reaisParaDolares(valorReais) { // Função para converter um valor em reais para dólares usando taxa fixa (1 dólar = 5 reais)
    return valorReais / 5; // Retorna o valor em reais dividido por 5 para obter o valor em dólares
  }
  
  const valorEmReais = 100; // Valor em reais
  
  console.log(`R$${valorEmReais} equivalem a aproximadamente $${reaisParaDolares(valorEmReais)} dólares.`); // Converte para dólares e exibe
  