function ehZero(numero) { // Função para verificar se o número é exatamente zero
    if (numero === 0) { // Verifica se o número é igual a 0
      return true; // Retorna true se a condição for verdadeira
    } else {
      return false; // Retorna false se a condição for falsa
    }
  }
  
  const num1 = 0; // Número 1
  const num2 = 5; // Número 2
  
  console.log(`O número ${num1} é zero? ${ehZero(num1)}`); // Exibe se num1 é zero
  console.log(`O número ${num2} é zero? ${ehZero(num2)}`); // Exibe se num2 é zero
  