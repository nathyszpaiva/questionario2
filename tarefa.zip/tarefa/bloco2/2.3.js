function temEntradaGratuita(idade) { // Função para verificar se a pessoa tem entrada gratuita (idade 65 ou mais)
    if (idade >= 65) { // Verifica se a idade é maior ou igual a 65
      return true; // Retorna true se a condição for verdadeira
    } else {
      return false; // Retorna false se a condição for falsa
    }
  }
  
  const idade1 = 70; // Idade 1
  const idade2 = 50; // Idade 2
  
  console.log(`Idade: ${idade1} - Entrada gratuita? ${temEntradaGratuita(idade1)}`); // Exibe se a pessoa tem entrada gratuita para idade1
  console.log(`Idade: ${idade2} - Entrada gratuita? ${temEntradaGratuita(idade2)}`); // Exibe se a pessoa tem entrada gratuita para idade2
  