function checarAprovacao(nota) { // Função para verificar se o aluno foi aprovado ou reprovado
    if (nota >= 7) { // Verifica se a nota é maior ou igual a 7
      return "Aprovado"; // Retorna "Aprovado" se a condição for verdadeira
    } else {
      return "Reprovado"; // Retorna "Reprovado" se a condição for falsa
    }
  }
  
  const nota1 = 8; // Nota 1
  const nota2 = 5; // Nota 2
  
  console.log(`Nota: ${nota1} - Resultado: ${checarAprovacao(nota1)}`); // Exibe o resultado da aprovação para nota1
  console.log(`Nota: ${nota2} - Resultado: ${checarAprovacao(nota2)}`); // Exibe o resultado da aprovação para nota2
  