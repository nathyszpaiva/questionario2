function tipoDeDia(diaSemana) {// Função para identificar se o dia é dia útil ou fim de semana
    if (diaSemana === "sábado" || diaSemana === "domingo") { // Verifica se o dia é "sábado" ou "domingo"
      return "Fim de semana"; // Retorna "Fim de semana" se for sábado ou domingo
    } else {
      return "Dia útil"; // Retorna "Dia útil" para os outros dias
    }
  }
 
  const dia1 = "segunda"; // Dia 1
  const dia2 = "domingo"; // Dia 2
  
  console.log(`O dia ${dia1} é: ${tipoDeDia(dia1)}`); // Exibe o tipo de dia para dia1
  console.log(`O dia ${dia2} é: ${tipoDeDia(dia2)}`); // Exibe o tipo de dia para dia2
  