function temperaturaAgradavel(temperatura) { // Função para verificar se a temperatura está agradável (entre 20 e 25 graus)
  if (temperatura >= 20 && temperatura <= 25) { // Verifica se a temperatura está entre 20 e 25 graus
    return true; // Retorna true se a condição for verdadeira
  } else {
    return false; // Retorna false se a condição for falsa
  }
}

const temp1 = 22; // Temperatura 1
const temp2 = 18; // Temperatura 2

console.log(`A temperatura ${temp1}°C está agradável? ${temperaturaAgradavel(temp1)}`);// Exibe se a temperatura está agradável para temp1
console.log(`A temperatura ${temp2}°C está agradável? ${temperaturaAgradavel(temp2)}`);// Exibe se a temperatura está agradável para temp2

  