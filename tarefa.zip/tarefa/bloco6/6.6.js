// Função que recebe um objeto produto e imprime o preço no console
function mostrarPrecoProduto(produto) {
    // Imprime no console a string "Preço: R$" seguida do valor da propriedade preco
    console.log(`Preço: R$${produto.preco}`);
  }
  
  const produto = {
    nome: "Caneta",
    preco: 2.5,
    codigo: "A123"
  };
  
  // Chama a função para mostrar o preço do produto
  mostrarPrecoProduto(produto);
  