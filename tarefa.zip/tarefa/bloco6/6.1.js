// Função que retorna um objeto descrevendo um carro
function descreverMeuCarro() {
    // Retorna um objeto com as propriedades marca, modelo e ano
    return {
      marca: "Toyota",
      modelo: "Corolla",
      ano: 2020
    };
  }
  
  // Chama a função e armazena o objeto retornado
  const meuCarro = descreverMeuCarro();
  
  // Exibe as informações do carro
  console.log("Descrição do carro:", meuCarro);
  