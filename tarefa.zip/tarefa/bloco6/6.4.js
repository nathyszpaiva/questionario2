// Função que atualiza a propriedade modelo do objeto carro e retorna o objeto modificado
function atualizarModeloCarro(carro, novoModelo) {
    // Atualiza a propriedade modelo com o novo valor
    carro.modelo = novoModelo;
    // Retorna o objeto carro modificado
    return carro;
  }
  
  const meuCarro = {
    marca: "Toyota",
    modelo: "Corolla",
    ano: 2020
  };
  
  // Atualiza o modelo do carro para "Camry"
  const carroAtualizado = atualizarModeloCarro(meuCarro, "Camry");
  
  // Exibe o objeto carro atualizado
  console.log("Carro atualizado:", carroAtualizado);
  