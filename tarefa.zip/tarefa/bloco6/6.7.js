// Função que adiciona a propriedade estoque ao objeto produto e retorna o objeto modificado
function adicionarEstoqueProduto(produto, quantidade) {
    // Adiciona a propriedade estoque com o valor da quantidade fornecida
    produto.estoque = quantidade;
    // Retorna o objeto produto modificado
    return produto;
  }
  
  const produto = {
    nome: "Caneta",
    preco: 2.5,
    codigo: "A123"
  };
  
  // Adiciona estoque ao produto
  const produtoComEstoque = adicionarEstoqueProduto(produto, 100);
  
  // Exibe o objeto produto com a nova propriedade estoque
  console.log("Produto com estoque:", produtoComEstoque);
  