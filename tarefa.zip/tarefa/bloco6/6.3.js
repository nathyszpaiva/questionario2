// Função que recebe um objeto carro e retorna o valor da propriedade ano
function getAnoCarro(carro) {
    // Retorna o ano de fabricação do carro
    return carro.ano;
  }
  
  const meuCarro = {
    marca: "Toyota",
    modelo: "Corolla",
    ano: 2020
  };
  
  // Chama a função para obter o ano do carro
  const ano = getAnoCarro(meuCarro);
  
  // Exibe o ano de fabricação do carro
  console.log("Ano do carro:", ano);
  