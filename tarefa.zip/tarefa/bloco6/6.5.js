// Função que cria um objeto produto com as propriedades nome, preco e codigo
function criarProduto(nome, preco, codigo) {
    // Retorna um objeto com as propriedades fornecidas
    return {
      nome: nome,
      preco: preco,
      codigo: codigo
    };
  }
  
  const produto = criarProduto("Caneta", 2.5, "A123");
  
  // Exibe o objeto produto criado
  console.log("Produto criado:", produto);
  