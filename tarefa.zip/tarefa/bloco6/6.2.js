// Função que recebe um objeto carro e retorna o valor da propriedade marca
function getMarcaCarro(carro) {
    // Retorna a marca do carro
    return carro.marca;
  }
  
  const meuCarro = {
    marca: "Toyota",
    modelo: "Corolla",
    ano: 2020
  };
  
  // Chama a função para obter a marca do carro
  const marca = getMarcaCarro(meuCarro);
  
  // Exibe a marca do carro
  console.log("Marca do carro:", marca);
  