let portaAberta = false; // Declara a variável portaAberta com valor booleano false (porta fechada)

function verificarPorta() { // Função para retornar o estado da porta
  return portaAberta; // Retorna o valor da variável portaAberta
}

console.log(`A porta está aberta? ${verificarPorta()}`); // Exibe no terminal se a porta está aberta (true) ou fechada (false)
