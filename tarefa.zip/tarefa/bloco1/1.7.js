function ehNumero(valor) { // Função para verificar se o valor é do tipo "number" 
    return typeof valor === "number"; // Retorna true se o tipo do valor for "number", caso contrário false
  }
  
  const valor1 = 42; // Número
  const valor2 = "texto"; // String
  
  console.log(`O valor ${valor1} é número? ${ehNumero(valor1)}`); // Verifica se valor1 é número e exibe o resultado
  console.log(`O valor "${valor2}" é número? ${ehNumero(valor2)}`); // Verifica se valor2 é número e exibe o resultado
  