function paginasRestantes(totalPaginas, paginasLidas) { // Função para calcular o número de páginas restantes para ler
    return totalPaginas - paginasLidas; // Retorna a diferença entre o total de páginas e as páginas já lidas
  }
  
  const totalPaginas = 300; // Total de páginas do livro
  const paginasLidas = 120; // Número de páginas já lidas
  const restantes = paginasRestantes(totalPaginas, paginasLidas); // Calcula as páginas restantes chamando a função paginasRestantes

  console.log(`Páginas restantes: ${restantes}`); // Exibe no terminal o número de páginas que faltam ser lidas

  