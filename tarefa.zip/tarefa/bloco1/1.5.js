function precoUnitario(precoTotalPacote, numeroItens) { // Função para calcular o preço de um único item em um pacote
    return precoTotalPacote / numeroItens; // Retorna o preço total do pacote dividido pelo número de itens
  }
  
  const precoTotalPacote = 50; // Define o preço total do pacote
  const numeroItens = 10; // Define o número de itens no pacote
  const precoPorItem = precoUnitario(precoTotalPacote, numeroItens); // Calcula o preço unitário chamando a função precoUnitario
  
  console.log(`Preço por unidade: R$ ${precoPorItem}`); // Exibe no terminal o preço de um único item
  