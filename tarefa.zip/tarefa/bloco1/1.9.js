function criarEmail(nomeUsuario) { // Função para criar um email simples a partir do nome de usuário
    return nomeUsuario + "@exemplo.com"; // Retorna o nome de usuário concatenado com o domínio "@exemplo.com"
  }
  
  const nomeUsuario = "joao"; // Nome do usuário
  const email = criarEmail(nomeUsuario); // Cria uma constante email que puxa os valores de criarEmail(nomeUsuario);
  
  console.log(`Email criado: ${email}`); // Exibe no terminal o email completo criado
  