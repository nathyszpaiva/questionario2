
function distanciaRestante(distanciaTotal, distanciaPercorrida) { // Função para calcular a distância restante para viajar
  return distanciaTotal - distanciaPercorrida; // Retorna a diferença entre a distância total e a distância já percorrida
}

const distanciaTotal = 500; // Define o total da distância da viagem em km
const distanciaPercorrida = 150; // Define a distância que já foi percorrida em quilômetros
const restante = distanciaRestante(distanciaTotal, distanciaPercorrida); // Calcula a distância restante chamando a função distanciaRestante

console.log(`Distância restante: ${restante} km`); // Mostra a distância que falta percorrer