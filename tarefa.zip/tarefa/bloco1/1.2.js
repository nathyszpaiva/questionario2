// Função para calcular 10% de gorjeta sobre o valor da refeição
function calcularGorjeta(valorRefeicao) { // Função de calcular gorjeta puxando o valor da refeição
  return valorRefeicao * 0.10; // Retorna o cálculo da gorjeta (valor da refeição pela porcentagem)
}

const valorRefeicao = 200; // Valor da refeição
const gorjeta = calcularGorjeta(valorRefeicao); // Cria uma constante gorjeta que puxa os valores que calculam a gorjeta pelo valor da refeição
console.log(`Gorjeta (10%): ${gorjeta}`); // Mostra o valor da gorjeta de 10%
