function minutosParaSegundos(minutos) { // Função para converter minutos em segundos
    return minutos * 60; // Retorna o valor em minutos multiplicado por 60 para obter segundos
  }
  
  const minutos = 5; // Define o valor em minutos
  const segundos = minutosParaSegundos(minutos); // Calcula o equivalente em segundos chamando a função minutosParaSegundos
  
  console.log(`${minutos} minutos equivalem a ${segundos} segundos.`); // Exibe no terminal o valor convertido em segundos
  