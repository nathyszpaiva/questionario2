function idadeEmDias(idadeAnos) { // Função para calcular a idade aproximada em dias (sem os anos bissextos)
    return idadeAnos * 365; // Retorna a idade em anos multiplicada por 365 para obter os dias
  }
  
  const idadeAnos = 30; // Idade em anos
  const idadeDias = idadeEmDias(idadeAnos); // Cria uma constante que puxa o valor de idadeEmDias(idadeAnos);
  console.log(`Idade aproximada em dias: ${idadeDias} dias.`); // Mostra a idade aproximada em dias
  