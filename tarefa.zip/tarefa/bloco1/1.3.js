// Função para converter polegadas em centímetros
function polegadasParaCm(polegadas) {
    return polegadas * 2.54; // Retorna o valor em centímetros multiplicando polegadas por 2.54
  }
  
  const medidaPolegadas = 10; // Valor em polegadas
  const medidaCm = polegadasParaCm(medidaPolegadas); // Cria uma constante medidaCm que puxa os valores de polegadasParaCm(medidaPolegadas);
  console.log(`${medidaPolegadas} polegadas equivalem a ${medidaCm} centímetros.`); // Mostra a equivalência de polegadas e cm
  