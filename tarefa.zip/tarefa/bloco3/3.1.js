function simularElevador() { // Função para simular o elevador subindo do 1º ao 5º andar
    for (let andar = 1; andar <= 5; andar++) { // Loop que vai do andar 1 até o andar 5
      console.log(`Subindo para o andar ${andar}`); // Imprime no console a mensagem indicando o andar atual
    }
  }

  simularElevador(); // Chama a função para executar a simulação
  