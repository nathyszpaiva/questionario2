function somarParesAteN(n) { // Função para somar todos os números pares de 2 até n (se n for par)
    let soma = 0; // Inicializa a variável soma com 0
    for (let i = 2; i <= n; i++) { // Loop que vai de 2 até n
      if (i % 2 === 0) { // Verifica se o número é par
        soma += i; // Adiciona o número par à soma
      }
    }
    return soma; // Retorna o valor total da soma
  }

  const n = 10; // Número limite para a soma
  
  console.log(`Soma dos números pares de 2 até ${n}: ${somarParesAteN(n)}`); // Calcula a soma dos pares até n e exibe
  