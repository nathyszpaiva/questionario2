function linhaDeAsteriscos(quantidade) { // Função para gerar uma linha com a quantidade especificada de asteriscos
    let resultado = ""; // Inicializa uma string vazia para armazenar os asteriscos
    for (let i = 0; i < quantidade; i++) { // Loop que vai de 0 até quantidade - 1
      resultado += "*"; // Adiciona um asterisco à string resultado a cada iteração
    }
    return resultado; // Retorna a string com os asteriscos
  }
  
  const quantidade = 5; // Quantidade de asteriscos desejada
  
  console.log(linhaDeAsteriscos(quantidade)); // Gera a linha de asteriscos e exibe no terminal
  