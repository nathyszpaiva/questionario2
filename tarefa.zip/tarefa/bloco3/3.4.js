function listarImparesAte9() { // Função para listar os números ímpares de 1 até 9
    for (let i = 1; i <= 9; i++) { // Loop que vai de 1 até 9
      if (i % 2 !== 0) { // Verifica se o número é ímpar
        console.log(i); // Imprime o número ímpar no console
      }
    }
  }

  listarImparesAte9(); // Chama a função para executar a listagem
  