function contarOvelhas() { // Função para contar ovelhas até 5
    for (let i = 1; i <= 5; i++) { // Loop que vai de 1 até 5
      if (i === 1) { // Imprime no console a contagem de ovelhas com pluralização correta
        console.log(`${i} ovelha...`);
      } else {
        console.log(`${i} ovelhas...`);
      }
    }
  }
  
  contarOvelhas(); // Chama a função para executar a contagem
  