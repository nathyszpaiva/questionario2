// Função para encontrar a menor pontuação em um array de pontuações
function encontrarMenorPonto(pontuacoes) {
    // Inicializa a variável menor com o primeiro elemento do array
    let menor = pontuacoes[0];
    // Loop para percorrer todas as pontuações
    for (let i = 1; i < pontuacoes.length; i++) {
      // Se a pontuação atual for menor que a menor encontrada até agora
      if (pontuacoes[i] < menor) {
        // Atualiza a variável menor com a nova menor pontuação
        menor = pontuacoes[i];
      }
    }
    // Retorna a menor pontuação encontrada
    return menor;
  }
  
  const pontuacoesJogador = [50, 20, 75, 10, 90]; // Array
  
  // Encontra a menor pontuação e exibe 
  const menorPontuacao = encontrarMenorPonto(pontuacoesJogador);
  console.log(`A menor pontuação é: ${menorPontuacao}`);
  