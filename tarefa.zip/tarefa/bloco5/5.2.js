// Função que recebe um array de cores e retorna a segunda cor (índice 1)
function segundaCor(cores) {
    // Retorna o elemento no índice 1 do array
    return cores[1];
  }
  
  const minhasCores = ["azul", "verde", "preto"]; // Array
  
  // Chama a função para obter a segunda cor e armazena o resultado
  const cor = segundaCor(minhasCores);
  
  // Exibe a segunda cor
  console.log("A segunda cor é:", cor);
  