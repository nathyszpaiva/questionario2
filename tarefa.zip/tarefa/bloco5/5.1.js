// Função que retorna um array com três cores favoritas
function minhasCoresFavoritas() {
    // Retorna um array com as cores "azul", "verde" e "preto"
    return ["azul", "verde", "preto"];
  }
  
  // Chama a função e armazena o resultado em uma variável
  const cores = minhasCoresFavoritas();
  
  // Exibe o array de cores favoritas
  console.log("Minhas cores favoritas são:", cores);
  