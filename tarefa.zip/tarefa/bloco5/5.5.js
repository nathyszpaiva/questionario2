// Função que verifica se o carrinho está vazio
function carrinhoVazio(carrinho) {
    // Retorna true se o tamanho do array for 0, caso contrário false
    return carrinho.length === 0;
  }
  
  const carrinho1 = []; // carrinho vazio
  const carrinho2 = ["produto1", "produto2"]; // carrinho com itens
  
  // Verifica se carrinho1 está vazio e exibe o resultado
  console.log(`Carrinho 1 está vazio? ${carrinhoVazio(carrinho1)}`);
  
  // Verifica se carrinho2 está vazio e exibe o resultado
  console.log(`Carrinho 2 está vazio? ${carrinhoVazio(carrinho2)}`);
  