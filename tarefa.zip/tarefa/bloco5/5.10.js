// Função que retorna um array com os 5 primeiros números ímpares
function criarArrayImpares() {
    // Retorna o array fixo com os números ímpares desejados
    return [1, 3, 5, 7, 9];
  }
  
  // Chama a função e armazena o array retornado
  const impares = criarArrayImpares();
  
  // Exibe o array de números ímpares
  console.log("Array de números ímpares:", impares);
  