// Função para verificar se um número foi sorteado em um array de números sorteados
function numeroFoiSorteado(numerosSorteados, numero) {
    // Loop para percorrer todos os números sorteados
    for (let i = 0; i < numerosSorteados.length; i++) {
      // Verifica se o número atual é igual ao número buscado
      if (numerosSorteados[i] === numero) {
        // Retorna true se o número foi encontrado
        return true;
      }
    }
    // Retorna false se o número não foi encontrado após o loop
    return false;
  }
  
  const sorteados = [5, 12, 23, 34, 45]; // array de números sorteados
  const numeroBusca = 23; // número para verificar
  
  // Verifica se o número foi sorteado e exibe o resultado
  console.log(`O número ${numeroBusca} foi sorteado? ${numeroFoiSorteado(sorteados, numeroBusca)}`);
  