// Função que recebe um array e retorna o penúltimo elemento
function penultimoElemento(lista) {
    // Retorna o elemento no índice lista.length - 2
    return lista[lista.length - 2];
  }
  
  const frutas = ["maçã", "banana", "laranja", "uva"]; // Array
  
  // Chama a função para obter o penúltimo elemento e armazena o resultado
  const penultimo = penultimoElemento(frutas);
  
  // Exibe o penúltimo elemento
  console.log("O penúltimo elemento é:", penultimo);
  