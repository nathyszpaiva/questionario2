// Função para calcular a média das notas de um aluno
function calcularMediaNotas(notas) {
    // Inicializa a variável soma com 0
    let soma = 0;
    // Loop para somar todas as notas do array
    for (let i = 0; i < notas.length; i++) {
      soma += notas[i];
    }
    // Calcula a média dividindo a soma pelo número de notas
    let media = soma / notas.length;
    // Retorna a média calculada
    return media;
  }
  
  const notasAluno = [7, 8, 9, 6, 10]; // Array
  
  // Calcula a média das notas e exibe
  console.log(`A média das notas é: ${calcularMediaNotas(notasAluno)}`);
  