// Função que adiciona uma nova cor ao final do array de cores e retorna o array modificado
function adicionarCor(cores, novaCor) {
    // Adiciona a nova cor ao final do array usando push
    cores.push(novaCor);
    // Retorna o array modificado
    return cores;
  }
  
  const minhasCores = ["azul", "verde", "preto"]; // array inicial de cores
  const corNova = "vermelho"; // nova cor para adicionar
  
  // Chama a função para adicionar a nova cor e armazena o resultado
  const coresAtualizadas = adicionarCor(minhasCores, corNova);
  
  // Exibe  o array atualizado de cores
  console.log("Cores atualizadas:", coresAtualizadas);
  