// Função para imprimir uma lista numerada no console
function imprimirListaNumerada(itens) {
    // Loop para percorrer todos os itens do array
    for (let i = 0; i < itens.length; i++) {
      // Imprime o número do item (i+1) seguido do ponto e do nome do item
      console.log(`${i + 1}. ${itens[i]}`);
    }
  }
  
  const listaCompras = ["Leite", "Pão", "Ovos"]; // array de itens
  
  // Chama a função para imprimir a lista numerada
  imprimirListaNumerada(listaCompras);
  